/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermarket_app;
import java.util.*;
import java.sql.*;
/**
 *
 * @author HP
 */
public class ConnectionProvider {
    
    public static Connection getConnection()
    {
        Connection con=null;
        try
        {
        Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/supermarket?zeroDateTimeBehavior=convertToNull","root","");
            return con;
        }
        catch(Exception e){System.out.println(e);}
        return con;
    }
}
