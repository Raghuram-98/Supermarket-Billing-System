/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermarket_app;
import java.util.*;
import java.sql.*;
import java.io.*;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.*;
import java.awt.Desktop;
import javax.swing.JOptionPane;
/**
 *
 * @author HP
 */
public class BillGenerator {
    
    Scanner sc=new Scanner(System.in);
    
    String i_id,i_name,i_brand;
    Integer demand,i_quantity,costPerItem,overall_cost,quan,overall;
    
    public Integer addItem(Integer total_cost,Integer biller_id,String cust_name,String mobile,String email,Integer bill_no,String iid,Integer quan)
    {
        
        Integer flag=0;
        try
        {
            Connection con=ConnectionProvider.getConnection();
            
            //System.out.println("Enter the Item ID:");
            i_id=iid;
            //System.out.println("Enter the Quantity");
            i_quantity=quan;
            
            Statement stmt=con.createStatement();
            
            ResultSet rs=stmt.executeQuery("Select Item_ID,Item_Name,Item_Brand,Item_Quantity,CostPerItem,OverallCost,Demand from stock_details");
            while(rs.next())
            {
                if(rs.getString(1).equals(i_id))
                {
                    flag=1;
                    i_name=rs.getString(2);
                    i_brand=rs.getString(3);
                    quan=rs.getInt(4);
                    if(quan<i_quantity)
                    {
                        JOptionPane.showMessageDialog(null,"Out of Stock");
                        flag=0;
                        break;
                    }
                    costPerItem=rs.getInt(5);
                    overall=rs.getInt(6);
                    demand=rs.getInt(7);
                    break;
                }
            }
            
            if(flag==0)
            {
                JOptionPane.showMessageDialog(null,"Item Not Available");
            }
            else
            {
                
                overall_cost=i_quantity*costPerItem;
                total_cost=total_cost+overall_cost;
                
                
                overall=overall-overall_cost;
                
                
                demand=demand+i_quantity;
                quan=quan-i_quantity;
                
                
                
                String str="Update stock_details set demand=? where Item_ID=?";
                PreparedStatement state=con.prepareStatement(str);
                state.setInt(1,demand);
                state.setString(2,i_id);
                int row=state.executeUpdate();
                
                
                str="Update stock_details set OverallCost=? where Item_ID=?";
                state=con.prepareStatement(str);
                state.setInt(1,overall);
                state.setString(2,i_id);
                row=state.executeUpdate();
                
                
                str="Update stock_details set Item_Quantity=? where Item_ID=?";
                state=con.prepareStatement(str);
                state.setInt(1,quan);
                state.setString(2,i_id);
                row=state.executeUpdate();
                
                
                

                str="Insert into purchaseditemsperday (Bill_No,Biller_ID,Cust_Name,Contact_No,email,Item_ID,Item_Name,Item_Brand,Quantity,Overall_Cost) Values(?,?,?,?,?,?,?,?,?,?)";
                state=con.prepareStatement(str);
                state.setInt(1,bill_no);
                state.setInt(2,biller_id);
                state.setString(3,cust_name);
                state.setString(4,mobile);
                state.setString(5,email);
                state.setString(6,i_id);
                state.setString(7,i_name);
                state.setString(8,i_brand);
                state.setInt(9,i_quantity);
                state.setInt(10,overall_cost);
                row=state.executeUpdate();


                str="Insert into billgenerator (Item_Name,Item_Brand,Quantity,Overall_Cost) Values(?,?,?,?)";
                state=con.prepareStatement(str);
                state.setString(1,i_name);
                state.setString(2,i_brand);
                state.setInt(3,i_quantity);
                state.setInt(4,overall_cost);
                row=state.executeUpdate();
            }
            con.close();
     
        }
        catch(Exception e){System.out.println(e);}
        
         return total_cost;
    }
    
    public void generateBill(Integer total_cost,Integer biller_id,String cust_name,String mobile,String email,Integer bill_no)
    {
        try
        {
           Connection con=ConnectionProvider.getConnection();
           
           Integer sno=1;
           String time=null;
           
           
           Document document =new Document();
           PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\HP\\Desktop\\Bills\\"+bill_no+" "+cust_name+".pdf"));
           document.open();

           
           System.out.println("");
           System.out.println("------------------------------------------------------------------------------------------------");
           document.add(new Paragraph("--------------------------------------------------------------------------------------------------------------------------------\n"));
           
           System.out.println("                                       DEMO SUPERMARKET");
           document.add(new Paragraph("                                                    DEMO SUPERMARKET\n"));
           
           System.out.println("                                       -----------------");
           document.add(new Paragraph("                                                   ----------------------------------\n\n"));
           
           System.out.println("");
           
           System.out.println("Bill No:"+bill_no+"                              Biller_ID:"+biller_id);
           document.add(new Paragraph("Bill No:"+bill_no+"                                                   Biller_ID:"+biller_id+"\n\n"));
           
           System.out.println("");
           System.out.println("Customer Name:"+cust_name+"                        Mobile:"+mobile);
           document.add(new Paragraph("Customer Name:"+cust_name+"                        Mobile:"+mobile+"\n\n"));
           
           System.out.println("");
           
           System.out.println("Customer Email ID : "+email);
           document.add(new Paragraph("Customer Email ID : "+email+"\n"));
           
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("Select * from billgenerator");
            System.out.println("------------------------------------------------------------------------------------------------");
            document.add(new Paragraph("--------------------------------------------------------------------------------------------------------------------------------\n"));
            
            System.out.printf("%-20s%-20s%-20s%-20s%-20s\n","Sno","Item Name","Item Brand","Quantity","Overall Cost");
            document.add(new Paragraph(String.format("%s %20s %20s %23s %23s \r\n", "Sno", "Item Name","Item Brand","Quantity","Overall Cost")));
            
            System.out.println("------------------------------------------------------------------------------------------------");
            document.add(new Paragraph("--------------------------------------------------------------------------------------------------------------------------------\n"));
            
            while(rs.next())
            {
                System.out.printf("%-20s%-20s%-20s%-20s%-20s\n",sno,rs.getString(1),rs.getString(2),rs.getInt(3),rs.getInt(4));
                document.add(new Paragraph(String.format("%s %25s %25s %25s %25s \r\n",sno,rs.getString(1),rs.getString(2),rs.getInt(3),rs.getInt(4))));
                
                time=rs.getString(5);
                sno++;
            }
            
            
            System.out.println("------------------------------------------------------------------------------------------------");
            document.add(new Paragraph("--------------------------------------------------------------------------------------------------------------------------------\n\n"));
            
            System.out.println("");
            System.out.println("Time:"+time+"                                          GRAND TOTAL= Rs."+total_cost);
            document.add(new Paragraph("Time:"+time+"                                          GRAND TOTAL= Rs."+total_cost+"\n\n"));
            
            System.out.println("");
            System.out.println("***************************************THANK YOU VISIT AGAIN************************************");
            document.add(new Paragraph("***************************************THANK YOU VISIT AGAIN************************************\n"));
            
            System.out.println("------------------------------------------------------------------------------------------------");
            document.add(new Paragraph("--------------------------------------------------------------------------------------------------------------------------------"));
            
            document.close();
            
            String str="Truncate table billgenerator";
            PreparedStatement state=con.prepareStatement(str);
            int row=state.executeUpdate();
            
            
            Integer flag1=0,visit,cost;
            stmt=con.createStatement();
            rs=stmt.executeQuery("Select mobile,visit,costOfPurchase from RegularCustomers");
            while(rs.next())
            {
                if(rs.getString(1).equals(mobile))
                {
                    flag1=1;
                    visit=rs.getInt(2);
                    visit=visit+1;
                    
                    
                    if(visit%10==0)
                    {
                        String subject = "Lucky Offer - Demo SuperMarket";
                        String message =  "Dear Customer, We are really happy to inform you that,"
                                + "you become our regular customer. We are priviledged to offer you 10% discount on your"
                                + "next purchase. SHOW THIS MAIL AS A PROOF."
                                + "Thank You.";

                        String user = "raghufxe@gmail.com";
                        String pass = "achuraghu";

                        SendMail.send(email,subject, message, user, pass);
                    }
                    
                    String cardid=cust_name+"_"+mobile;
                    if(visit==5)
                    {
                        //String cardid=cust_name+"_"+mobile;
                        Integer bal=100;
                        str="Insert into giftcard(Card_Id,Cust_Name,Cust_email,Mobile_No,Balance_Amount)values(?,?,?,?,?)";
                        state=con.prepareStatement(str);
                        state.setString(1,cardid);
                        state.setString(2,cust_name);
                        state.setString(3,email);
                        state.setString(4,mobile);
                        state.setInt(5,bal);
                        row=state.executeUpdate();
                        
                        
                        String subject = "Gift Card Regd - Demo SuperMarket";
                        String message =  "Dear Customer, We are really happy to inform you that,"
                                + "you become our regular customer. We are priviledged to offer you a giftcard with initial amount of Rs.100\n"
                                + "The amount will be increment 10% of the total cost in your upcoming purchases.\n\n"
                                + "Your Unique Card ID is "+cardid+".\n\n"
                                + "Don't Share your ID.\n\n"
                                + "Thank You.";

                        String user = "raghufxe@gmail.com";
                        String pass = "achuraghu";

                        SendMail.send(email,subject, message, user, pass);
                        
                    }
                    
                    if(visit>5)
                    {
                        Integer balamt=total_cost*(10/100);
                        str="Update giftcard set balance_amount=balance_amount+? where mobile_no=?";
                        state=con.prepareStatement(str);
                        state.setInt(1,balamt);
                        state.setString(2,mobile);
                        row=state.executeUpdate();
                        
                        Integer amt=0;
                        rs=stmt.executeQuery("Select balance_amount from giftcard where mobile_no="+mobile);
                        while(rs.next())
                        {
                            amt=rs.getInt(1);
                        }
                        
                        String subject = "Gift Card Regd - Demo SuperMarket";
                        String message =  "Dear Customer,\n"
                                + "Thanks for purchasing in our Supermarket.\n\n"
                                + "Your gift card is credited with the amount of Rs."+balamt+".\n\n"
                                + "Your Current Balance is Rs."+amt+".\n\n"
                                + "Thank You.";

                        String user = "raghufxe@gmail.com";
                        String pass = "achuraghu";

                        SendMail.send(email,subject, message, user, pass);
                        
                    }
                    
                    cost=rs.getInt(3);
                    cost=cost+total_cost;
                    
                    str="update RegularCustomers set visit=? where mobile=?";
                    state=con.prepareStatement(str);
                    state.setInt(1,visit);
                    state.setString(2,mobile);
                    row=state.executeUpdate();
                    
                    
                    str="update RegularCustomers set costOfPurchase=? where mobile=?";
                    state=con.prepareStatement(str);
                    state.setInt(1,cost);
                    state.setString(2,mobile);
                    row=state.executeUpdate();
                }
            }
            if(flag1==0)
            {
                str="Insert into regularcustomers (cust_name,mobile,email,costOfPurchase) Values(?,?,?,?)";
                state=con.prepareStatement(str);
                state.setString(1,cust_name);
                state.setString(2,mobile);
                state.setString(3,email);
                state.setInt(4,total_cost);
                row=state.executeUpdate();
            }
            
            Desktop.getDesktop().open(new File("C:\\Users\\HP\\Desktop\\Bills\\"+bill_no+" "+cust_name+".pdf"));
            
            con.close();
           
        }
        catch(Exception e){System.out.println(e);}
    }
    
}
